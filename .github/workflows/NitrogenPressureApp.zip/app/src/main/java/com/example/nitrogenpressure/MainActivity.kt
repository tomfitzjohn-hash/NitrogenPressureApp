package com.example.nitrogenpressure

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                PressureCalculatorApp()
            }
        }
    }
}

@Composable
fun PressureCalculatorApp() {
    var initialPressure by remember { mutableStateOf("") }
    var initialTemp by remember { mutableStateOf("") }
    var finalTemp by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("—") }

    fun calculate() {
        val p1 = initialPressure.toDoubleOrNull()
        val t1C = initialTemp.toDoubleOrNull()
        val t2C = finalTemp.toDoubleOrNull()

        if (p1 != null && t1C != null && t2C != null) {
            val t1K = t1C + 273.15
            val t2K = t2C + 273.15
            if (t1K > 0 && t2K > 0) {
                val p2 = p1 * (t2K / t1K)
                result = String.format("%.2f psi", p2)
            } else {
                result = "Invalid temperature values"
            }
        } else {
            result = "Enter valid numeric inputs"
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Nitrogen Pressure Calculator") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedTextField(
                value = initialPressure,
                onValueChange = { initialPressure = it },
                label = { Text("Initial Pressure (psi)") },
                singleLine = true
            )

            OutlinedTextField(
                value = initialTemp,
                onValueChange = { initialTemp = it },
                label = { Text("Initial Temperature (°C)") },
                singleLine = true
            )

            OutlinedTextField(
                value = finalTemp,
                onValueChange = { finalTemp = it },
                label = { Text("Final Temperature (°C)") },
                singleLine = true
            )

            Button(onClick = { calculate() }) {
                Text("Calculate Final Pressure")
            }

            Text(text = "Final Pressure: $result", style = MaterialTheme.typography.titleMedium)
        }
    }
}
